package com.nutrition.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class DietServiceTest {

	@Test
	public void testGetDietPlan() {
		fail("Not yet implemented");
	}

	@Test
	public void testSaveDietPlan() {
		fail("Not yet implemented");
	}

	@Test
	public void testSaveFoodDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetDietDetails() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetFoodDetails() {
		fail("Not yet implemented");
	}

}
