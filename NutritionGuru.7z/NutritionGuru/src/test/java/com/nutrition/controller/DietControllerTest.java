//package com.nutrition.controller;
//
//import static org.junit.Assert.fail;
//
//import org.junit.Test;
//
//public class DietControllerTest {
//
//	@Test
//	public void testDietPlanDetails() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSaveDietPlan() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testSaveFoodDetails() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testGetDietDetails() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	public void testGetFoodDetails() {
//		fail("Not yet implemented");
//	}
//
//}
