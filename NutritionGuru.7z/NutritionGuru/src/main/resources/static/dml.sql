INSERT INTO `nutrition`.`diet_master_history`
(`dite_history_id`,
`dm_diet_item1`,
`dm_diet_item2`,
`dm_diet_item3`,
`dm_diet_item4`,
`dm_diet_item5`,
`dm_calories_in_diet`)
VALUES('2', 'Rice, 1 Cup, 5g Cal', 'Pulse, 1 Cup, 7g Cal', 'Vegitable, 1 Cup, 10g Cal', 'Salad, 1 Cup, 4g Cal', 'Curd, 1 Cup, 8g Cal', '34g Cal');

