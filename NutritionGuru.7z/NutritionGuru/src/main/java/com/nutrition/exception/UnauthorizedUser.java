package com.nutrition.exception;

public class UnauthorizedUser extends RuntimeException {
	private static final long serialVersionUID = 1L;
}