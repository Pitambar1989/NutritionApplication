package com.nutrition;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@EnableAutoConfiguration
@SpringBootApplication
public class NutritionApplication {
	public static void main(String[] args) {
		SpringApplication.run(NutritionApplication.class, args);
	}
}
